#!/bin/bash
echo "🔧 Fixing Gradle cache & Flutter dependencies..."

# 1. Stop all Gradle daemons
echo "→ Stopping Gradle daemons..."
cd android && ./gradlew --stop 2>/dev/null || true
cd ..

# 2. Delete corrupted Gradle cache
echo "→ Deleting corrupted Gradle cache..."
rm -rf ~/.gradle/caches/
rm -rf ~/.gradle/wrapper/dists/

# 3. Clean Flutter build & fetch deps
echo "→ Cleaning Flutter project..."
flutter clean
flutter pub get

echo ""
echo "✅ Done! Sekarang jalankan:"
echo "   flutter build apk"
echo "   atau: flutter run"
