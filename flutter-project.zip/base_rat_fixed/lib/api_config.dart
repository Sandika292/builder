const String kServerBase = "http://server-private.jhonaleystore.systems:2218";
